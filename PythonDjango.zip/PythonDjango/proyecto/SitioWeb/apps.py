from django.apps import AppConfig


class SitiowebConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'SitioWeb'
